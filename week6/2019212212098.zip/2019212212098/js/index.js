var bg = document.getElementById("bg")
console.log(bg.width,bg.height)